import React from 'react'

const OnlineOrder = () => {
  return (
    <div>
        
    </div>
  )
}

export default OnlineOrder