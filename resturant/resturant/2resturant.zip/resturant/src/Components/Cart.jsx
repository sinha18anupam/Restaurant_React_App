import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';

import './Cart.css';

const Cart = () => {
  const location = useLocation();
  const navigate = useNavigate();

  const { item } = location.state || {};

  const handleRemove = () => {
    // Implement logic to  the item from the cart
  };

  const handleOrder = () => {
    // Implement logic to place an order
  };

  return (
    <div className='Cart'>
      <img src={item.img} alt={item.name} />
      <h1>Shopping Cart</h1>
      
      {item ? (
        <div className='item'>
          <h3>{item.name}</h3>
          <p>{item.description}</p>
          <h3><b>Price: ₹{item.price}</b></h3>
          {item.oldPrice && <p>Old Price: ₹<del>{item.oldPrice}</del></p>}
          <button onClick={handleOrder}>Order</button>
          <button id='remove' onClick={handleRemove}>Remove</button>
        </div>
      ) : (
        <p className="centered-text">Your cart is empty.</p>
      )}
    </div>
  );
};

export default Cart;
