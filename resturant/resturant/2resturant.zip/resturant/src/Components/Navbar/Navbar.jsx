import React, { useState, useEffect } from 'react';
import './Navbar.css';
import logo from '../Assets/logo.png.jpg';
import menuIcon from '../Assets/menu.png'; 
import cancelIcon from '../Assets/x-mark.png'
import { useCart } from '../CartPage/CartContext';
// import cancelIcon from '../Assets/cancel.png'

const Navbar = () => {
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth <= 600);
    };

    handleResize();
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  const toggleDrawer = () => {
    setIsDrawerOpen(!isDrawerOpen);
  };
  const { cartCount } = useCart();

  return (
    <nav id="navbar">
      <div id="logo">
        <a href="/"><img src={logo} alt=""/></a>
      </div>

      {isMobile ? (
        <>
          <div className="menu-toggle" onClick={toggleDrawer}>
            {isDrawerOpen ? <i className="material-icons"></i> : <img src={menuIcon} alt="Menu" />}
          </div>

          <ul className={`drawer ${isDrawerOpen ? 'open' : ''}`}>
            <li className="item"><a href="/">Home</a></li>
            <li className="item"><a href="/service">Services</a></li>
            <li className="item"><a href="/about">About Us</a></li>
            <li className="item"><a href="/contact">Contact Us</a></li>
            <li className="close-icon" onClick={toggleDrawer}><i className="material-icons">
              <img src={cancelIcon} alt="" />
              </i></li>
          </ul>
        </>
      ) : (
        <ul className="navbar-list">
          <li className="item"><a href="/">Home</a></li>
          <li className="item"><a href="/service">Services</a></li>
          {/* <li className="item"><a href="/about">About Us</a></li> */}
          <li className="item"><a href="/contact">Contact us</a></li>
          <li className="item"><a href="/cart">Cart {cartCount} </a></li>
          {/* <li className="item"><Link to="/cart">Cart</Link></li> */}
        </ul>
      )}
    </nav>
  );
};

export default Navbar;
