import React from 'react'
import VegCorousel from './HeroVeg'
import VegList from './VegList'

const Pureveg = () => {
  return (
    <div>
        <VegCorousel/>
       <VegList/>
      

    </div>
  )
}

export default Pureveg