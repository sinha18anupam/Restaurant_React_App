import React from 'react'
import './VegList.css'
import arrow from '../Assets/arrow.png'
import { Link, useNavigate } from 'react-router-dom';

import Veglistdata from '../../Components/PureVeg/Veglistdata';
import { useCart } from '../CartPage/CartContext';
import frontPagedata from '../Categories/frontPagedata';

const VegList = () => {
  
  const navigate = useNavigate();
  const { addToCart, updateCartCount } = useCart();

  const handleAddToCart = (item) => {
    addToCart(item); // Add item to cart
    updateCartCount((prevCount) => prevCount + 1); // Increment cart count
    navigate('/cart'); // Navigate to cart page
  };
  return (

    <>
   
     <div className="scanner">
    <img src="https://justmyroots.com/a3b6cdf74966b8a33ce3eb882f05e9f1.gif" alt="" />

    </div>
    <hr />
    <div className='Trending'>
        <h1 id='topic-trending'>TRENDING DISHES</h1>
        <h4 id='topic-trending'><a href="/">view more</a>  <img src={arrow} alt="" /></h4>
    </div>

      
    <div className='new-collection'>
     
     <hr/>
     <div className="collection">
     {Veglistdata.map((item, i) => ( 
  <div key={i} className="product-item">
    <img src={item.img} alt={item.name} />
    <h3>{item.name}</h3>
    <p>{item.description}</p>
    <h3><b>₹{Number(item.price)}</b></h3>
    <del>₹{Number(item.old_price)}</del>
    <br/>
    <Link to="/cart">
              <button className='add-to-cart' onClick={() => handleAddToCart(item)}>Add to Cart</button>
            </Link>
  </div>
))}
     </div>
   </div>
  
   
    </>
  )
}

export default VegList