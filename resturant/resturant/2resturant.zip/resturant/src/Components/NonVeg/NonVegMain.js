import React from 'react'
import NonVeg from './NonVeg'

const NonVegMain = () => {
  return (
    <div>
        <NonVeg/>
    </div>
  )
}

export default NonVegMain