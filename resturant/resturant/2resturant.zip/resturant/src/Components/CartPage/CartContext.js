// // CartContext.js
// import React, { createContext, useContext, useState } from 'react';

import { createContext, useContext, useState } from "react";
import Veglistdata from "../PureVeg/Veglistdata";

// const CartContext = createContext();

// export const useCart = () => useContext(CartContext);

// export const CartProvider = ({ children }) => {
//   const [cartItems, setCartItems] = useState([]);

//   const addToCart = (item) => {
//     setCartItems([...cartItems, item]);
//   };

//   const removeFromCart = (itemToRemove) => {
//     setCartItems(cartItems.filter(item => item.id !== itemToRemove.id));
//   };

//   const clearCart = () => {
//     setCartItems([]);
//   };

//   return (
//     <CartContext.Provider value={{ cartItems, addToCart, removeFromCart, clearCart }}>
//       {children}
//     </CartContext.Provider>
//   );
// };

// CartContext.jsimport React, { createContext, useContext, useState } from 'react';

const CartContext = createContext();

export const useCart = () => useContext(CartContext);

export const CartProvider = ({ children }) => {
    const [cartCount, setCartCount] = useState(0);

    const updateCartCount = (count) => {
      setCartCount(count);
    };

  
    const [cartItems, setCartItems] = useState([]);

    const addToCart = (item, source) => {
      console.log('Adding to cart:', item, 'Source:', source); // Log item and source for debugging
    
      const existingItemIndex = cartItems.findIndex((cartItem) => cartItem.id === item.id);
    
      if (existingItemIndex !== -1) {
        const updatedCartItems = [...cartItems];
        updatedCartItems[existingItemIndex].quantity += 1;
        setCartItems(updatedCartItems);
      } else {
        if (source === 'DishList') { // Check if the item is from DishList component
          console.log('Adding from DishList:', item); // Log that the item is from DishList
          setCartItems([...cartItems, { ...item, quantity: 1, source: 'DishList' }]);
        } else {
          const product = Veglistdata.find((vegItem) => vegItem.id === item.id);
          if (product) {
            console.log('Adding from Veglistdata:', product); // Log that the item is from Veglistdata
            setCartItems([...cartItems, { ...product, quantity: 1, source: 'Veglistdata' }]);
          }
        }
      }
    };
    
    
    const removeFromCart = (itemToRemove) => {
      setCartItems(cartItems.filter((cartItem) => cartItem.id !== itemToRemove.id));
    };

    const updateQuantity = (itemId, newQuantity) => {
      const updatedCartItems = cartItems.map((cartItem) =>
        cartItem.id === itemId ? { ...cartItem, quantity: newQuantity } : cartItem
      );
      setCartItems(updatedCartItems);
    };

    const clearCart = () => {
      setCartItems([]);
    };

    return (
      <CartContext.Provider value={{ cartCount, updateCartCount, cartItems, addToCart, removeFromCart, updateQuantity, clearCart }}>
        {children}
      </CartContext.Provider>
    );
};
