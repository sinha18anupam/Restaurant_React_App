// import React from 'react'
// import './CartPage.css'
// const CartPage = () => {
//   return (
//     <div className='cartsection'>
//         <h1> cartPage
//         </h1>
//     </div>a
//   )
// }
import React, { useState } from 'react';
import { useCart } from './CartContext'; // Update path to CartContext
import './CartPage.css';
import frontPagedata from '../Categories/frontPagedata'; // Import frontPagedata
import Veglistdata from '../PureVeg/Veglistdata';

const CartPage = () => {
  const [showModal, setShowModal] = useState(false);
  const [showModal2, setShowModal2] = useState(false);
  const [showModal3, setShowModal3] = useState(false);
  const [showModal4, setShowModal4] = useState(false);

  const [formData, setFormData] = useState({
    name: '',
    address: '',
    landmark: '',
    phone: '',
    mobile: '',
    altMobile: '',
  });
  const { cartItems, removeFromCart, updateQuantity } = useCart() || { cartItems: [] }; // Initialize cartItems with an empty array if useCart hook returns null

  const totalCartPrice = cartItems.reduce((total, cartItem) => total + cartItem.price * cartItem.quantity, 0);

  const handleQuantityChange = (cartItem, newQuantity) => {
    if (newQuantity > 0) {
      updateQuantity(cartItem.id, newQuantity); // Use cartItem.id to identify the item
    } else {
      removeFromCart(cartItem);
    }
  };
  
  const loadScript = (src) => {
    return new Promise((resolve) => {
      const script = document.createElement('script');
      script.src = src;
      script.onload = () => {
        resolve(true);
      };
      script.onerror = () => {
        resolve(false);
      };
      document.body.appendChild(script);
    });
  };
  
  const displayRazor = async () => {
  
    const res = await loadScript('https://checkout.razorpay.com/v1/checkout.js');
    if (!res) {
      alert('Failed to load Razorpay. Please check your internet connection.');
      return;
    }

    const options = {
      key: "rzp_test_0kUFOaNwOklBWd",
      currency: "INR",
      amount: totalCartPrice * 100, // Convert totalCartPrice to paise (100x amount)
      name: "total Bill",
      description: "thnaks for the order",
      image: "",
      handler: function (response) {
        setShowModal(true);
      },
      prefill: {
        name: "",
      },
    };

    const paymentObject = new window.Razorpay(options);
    paymentObject.open();
  };
  const handleChange = (e) => {
    const { name, value } = e.target;
  
    // Regex for up to 10 digits
    const regex = /^[0-9]{0,10}$/;
  
    if ((name === 'phone' || name === 'altMobile') && regex.test(value)) {
      setFormData((prevState) => ({
        ...prevState,
        [name]: value,
      }));
    } else if (name !== 'Name') {
      // Exclude the Name field from being updated if not valid
      setFormData((prevState) => ({
        ...prevState,
        [name]: value,
      }));
    }
  };
  const handleCOD = () => {
    console.log('Form Data:', formData);
    console.log('Product Details:');
    cartItems.forEach((cartItem) => {
      const product = cartItem.source === 'Veglistdata' ? Veglistdata.find(item => item.id === cartItem.id) : frontPagedata.find(item => item.id === cartItem.id);
      console.log(`${cartItem.quantity}x ${product.name} - ₹${(product.price * cartItem.quantity).toFixed(2)}`);
    });
    console.log('Total Price:', totalCartPrice.toFixed(2));
  };

  return (
    <div className='cartsection'>
      <h1>Cart Page</h1>
      <table className="cart-table">
        <thead>
          <tr>
            <th>Image</th>
            <th>Name</th>
            <th>Description</th>
            <th>Price</th>
            <th>Quantity</th>
            <th>Total Amount</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
        {cartItems.map((cartItem) => {
    const product = cartItem.source === 'Veglistdata' ? Veglistdata.find(item => item.id === cartItem.id) : frontPagedata.find(item => item.id === cartItem.id);


            return (
              <tr key={cartItem.id}>
                <td><img src={product.img} alt={product.name} /></td>
                <td>{product.name}</td>
                <td>{product.description}</td>
                <td>₹{product.price}</td>
                <td>
                  <button className='add-remove' onClick={() => handleQuantityChange(cartItem, cartItem.quantity - 1)}>-</button>
                  {cartItem.quantity}
                  <button className='add-remove2'onClick={() => handleQuantityChange(cartItem, cartItem.quantity + 1)}>+</button>
                  
                </td>
                <td>₹{(product.price * cartItem.quantity).toFixed(2)}</td>
                
                <td><button className='remove' onClick={() => removeFromCart(cartItem)}>Remove</button></td>
                
              </tr>
            );
          })}
        </tbody>
      </table>
      <div className="cart-total">
        <h2>Total Price: ₹{totalCartPrice.toFixed(2)}</h2>
        <button onClick={() => setShowModal(true)}className='checkout' >checkout</button>
      </div>
      {showModal && (
        <div className="modal">
          <div className="modal-content">
            <span className="close" onClick={() => setShowModal(false)}>&times;</span>
            <h2>Order Confirmation</h2>
            <ul>
              {cartItems.map((cartItem) => (
                
                <li key={cartItem.id}>
                  
                  {cartItem.quantity}x {cartItem.name} - ₹{(cartItem.quantity * cartItem.price).toFixed(2)}
                </li>
              ))}
               {cartItems.map((cartItem) => (
              <li  key={cartItem.id}>
              <img src={cartItem.img} alt={cartItem.name}/>
              </li>
              ))}
              {cartItems.map((cartItem) => (
                <li key={cartItem.id}>
                  {cartItem.description} {cartItem.name}  
                </li>
              ))}
              <li>

              </li>
            </ul>
            <p>Total: ₹{totalCartPrice.toFixed(2)}</p>
            <button onClick={() => { setShowModal(false); setShowModal2(true); }} className='checkout'>Proceed to Payment</button>
           
          </div>
        </div>
      )}
      {showModal2 && (
  <div className="modal">
    <div className="modal-content">
      <span className="close" onClick={() => setShowModal2(false)}>&times;</span>
      <h2>Order Confirmation</h2>
      <form>
      <div className="form-group">
          <label htmlFor="Name">Name:</label>
          <input type="text" id="Name" name="Name" value={formData.Name} onChange={handleChange} required  placeholder="Enter your Name" />
        </div>
        <div className="form-group">
          <label htmlFor="address">Address:</label>
          <input type="text" id="address" value={formData.address} onChange={handleChange} name="address" placeholder="Enter your address" required />
        </div>
        <div className="form-group">
          <label htmlFor="landmark">Landmark:</label>
          <input type="text" id="landmark" name="landmark" value={formData.landmark} onChange={handleChange} placeholder="Enter landmark (optional)" />
        </div>
        <div className="form-group">
          <label htmlFor="phone">Phone No:</label>
          <input type="number" id="phone" name="phone"  value={formData.phone} maxLength={10} onChange={handleChange} placeholder="Enter your phone number" required />
        </div>
        
        <div className="form-group">
          <label htmlFor="altMobile">Alternate Mobile No:</label>
          <input type="number" id="altMobile" name="altMobile" maxLength={10} value={formData.altMobile} onChange={handleChange} placeholder="Enter alternate mobile number" />
        </div> 
        <div className='tottal'>
        Total: ₹{totalCartPrice.toFixed(2)}

        </div>

        <div className="buttons">
          
          <button type="button" onClick={() => { setShowModal2(false); setShowModal3(true); }} className="razorpay" >procced to payment</button>
        </div>
      </form>
    </div>
  </div>
)}
{showModal3 && (
        <div className="modal">
          <div className="modal-content">
            <span className="close" onClick={() => { setShowModal3(false); setShowModal2(true); }}>&times;</span>
            <h2>Order Confirmation</h2>
          
            <p>Total: ₹{totalCartPrice.toFixed(2)}</p>
            <button onClick={showModal4} className='checkout'>checkout now</button>
          
          </div>
        </div>
      )}

      {showModal4 && (
        <div className="modal">
          <div className="modal-content">
            <span className="close" onClick={() => { setShowModal4(false); setShowModal3(true); }}>&times;</span>
            <h2>Preview Order</h2>
          
            <p>Total: ₹{totalCartPrice.toFixed(2)}</p>
            <button onClick={displayRazor} className='checkout'>checkout now</button>
           <button onClick={handleCOD}>COD</button>
          </div>
        </div>
      )}

     
    </div>
  );
};

export default CartPage;
