import React from 'react';
import './App.css'
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Navbar from './Components/Navbar/Navbar';
import MainCategories from './Components/Categories/MainCategories';
import Footer from './Components/Footer/Footer';
import MainService from './Components/Services/MainService';
import Pureveg from './Components/PureVeg/Pureveg';
import NonVeg from './Components/NonVeg/NonVeg';
import Hero from './Components/Categories/Hero';
import CartPage from './Components/CartPage/CartPage';
import { CartProvider } from './Components/CartPage/CartContext';
import Register from './Components/Register/Register';
import Login from './Components/Login/Login';
import Internalpage from './Internalpage';

function App() {
  const isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';

  return (
    <CartProvider>
    <Router>
      <Routes>
        <Route path="/" element={isLoggedIn ? <Navigate to="/internal" /> : <Register />} />
        <Route path="/login" element={<Login />} />
        <Route path="/internal" element={<Internalpage />} />
        <Route path="/cart" element={<CartPage />} />

      </Routes>
    </Router>
      </CartProvider>
  );
};


export default App;
