import React from 'react'
import Navbar from './Components/Navbar/Navbar';
import Hero from './Components/Categories/Hero';
import { Route, Router, Routes } from 'react-router-dom';
import MainCategories from './Components/Categories/MainCategories';
import MainService from './Components/Services/MainService';
import Pureveg from './Components/PureVeg/Pureveg';
import CartPage from './Components/CartPage/CartPage';
import Footer from './Components/Footer/Footer';
import { CartProvider } from './Components/CartPage/CartContext';


const InternalPage = () => (
    <>
   <div>
      <Navbar />
      <Hero />
      <Routes>
        <Route path="/" element={<MainCategories />} />
        <Route path="/service" element={<MainService />} />
        <Route path="/pureVeg" element={<Pureveg />} />
        <Route path="/cart" element={<CartPage />} />
      </Routes>
      <Footer />
    
      </div>
    </>
  );      

export default InternalPage