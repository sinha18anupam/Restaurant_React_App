import React from 'react';
import './App.css'
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Navbar from './Components/Navbar/Navbar';
import MainCategories from './Components/Categories/MainCategories';
import Footer from './Components/Footer/Footer';
import MainService from './Components/Services/MainService';
import Pureveg from './Components/PureVeg/Pureveg';
import NonVeg from './Components/NonVeg/NonVeg';
import Hero from './Components/Categories/Hero';
import CartPage from './Components/CartPage/CartPage';
import { CartProvider } from './Components/CartPage/CartContext';
import Register from './Components/Register/Register';
import Login from './Components/Login/Login';
// import Internalpage from './Internalpage';
import InternalPage from './Internalpage';
import Subcategories from './Components/PureVeg/Pureveg';

function App() {
  const isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';

  return (
    <CartProvider>
<Router>
      <Routes>
<Route path="/signin" element={<Register />} />
          <Route path="/login" element={<Login />} />
          </Routes>
          </Router>
      <Navbar />
      <Hero />
    <Router>
      <Routes>
    
          {/* <Route path="/" element={<InternalPage />} /> */}
          {/* <Route path="/cart" element={<CartPage />} /> */}
          <Route path="/" element={<MainCategories />} />
        <Route path="/service" element={<MainService />} />
        {/* <Route path="/pureVeg" element={<Pureveg />} /> */}
        <Route path="/cart" element={<CartPage />} />
        <Route path="/subcategories/:category" element={<Subcategories />} />
       


      </Routes>

    </Router>
    <Footer />
      </CartProvider>
  );
};


export default App;
