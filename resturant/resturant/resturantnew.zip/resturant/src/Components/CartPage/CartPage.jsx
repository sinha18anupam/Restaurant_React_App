
import React, { useEffect, useState } from 'react';
import { useCart } from './CartContext'; // Update path to CartContext
import './CartPage.css';
// import frontPagedata from '../Categories/frontPagedata'; // Import frontPagedata
// import Veglistdata from '../PureVeg/Veglistdata';
import axios from 'axios';

const CartPage = () => {
  const [showModal, setShowModal] = useState(false);
  const [showModal2, setShowModal2] = useState(false);
  const [showModal3, setShowModal3] = useState(false);
  const [showModal4, setShowModal4] = useState(false);

  const [formData, setFormData] = useState({
    Name: '',
    address: '',
    landmark: '',
    phone: '',
    altMobile: '',
    zip:'',
  });
  const { cartItems, removeFromCart } = useCart(); 
  const [totalCartPrice, setTotalCartPrice] = useState(0);

  const handleProceedToPayment = () => {
    console.log('Form Data:', formData); // Check form data before validation
    if (
      formData.Name &&
      formData.address &&
      formData.phone &&
      formData.altMobile &&
      formData.zip
    ) {
      setShowModal(false);
      setShowModal4(true);
    } else {
      console.log('Form Data Incomplete:', formData); // Log incomplte form data for debugging
      alert('Please fill in all the required fields.');
    }
  };
  
  
  const loadScript = (src) => {
    return new Promise((resolve) => {
      const script = document.createElement('script');
      script.src = src;
      script.onload = () => {
        resolve(true);
      };
      script.onerror = () => {
        resolve(false);
      };
      document.body.appendChild(script);
    });
  };
  
  const displayRazor = async () => {
  
    const res = await loadScript('https://checkout.razorpay.com/v1/checkout.js');
    if (!res) {
      alert('Failed to load Razorpay. Please check your internet connection.');
      return;
    }

    const options = {
      key: "rzp_test_0kUFOaNwOklBWd",
      currency: "INR",
      amount: totalCartPrice * 100, // Convert totalCartPrice to paise (100x amount)
      name: "total Bill",
      description: "thnaks for the order",
      image: "",
      handler: function (response) {
        setShowModal(true);
      },
      prefill: {
        name: "",
      },
    };

    const paymentObject = new window.Razorpay(options);
    paymentObject.open();
  };
  const handleChange = (e) => {
    const { name, value } = e.target;
    console.log('Name Field Value:', value); // Add this line to check the value
    setFormData((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const [cardData, setCardData] = useState(() => {
    const storedCartData = localStorage.getItem('cartData');
    return storedCartData ? JSON.parse(storedCartData) : [];
  });
  const fetchData = async () => {
    const userData = localStorage.getItem('userid');
    try {
      const response = await axios.get(`http://localhost:5000/api/card/get/${userData}`);
      console.log(response.data);
      if (response.data.products && Array.isArray(response.data.products)) {
        // Calculate total price when card data is fetched
        setCardData(response.data.products);
        const totalPrice = response.data.products.reduce((total, item) => total + item.price, 0);
        setTotalCartPrice(totalPrice);
  
        // Store card data in local storage
        localStorage.setItem('cartData', JSON.stringify(response.data.products));
      } else {
        console.error('Response data does not contain products array:', response.data);
      }
    } catch (error) {
      console.error('Error fetching card data:', error);
    }
  };
  
  useEffect(() => {
    fetchData();
    // updateQuantity();
    // handleQuantityChange()
  }, []);
 
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [quantityChanged, setQuantityChanged] = useState(false);

  const handleQuantityChange = async (cardId, newQuantity) => {
    if (newQuantity >= 1) {
      try {
        setLoading(true);
        setError(null);

        const response = await axios.put(`http://localhost:5000/api/card/up/${cardId}`, { quantity: newQuantity });
        console.log(response.data);

        setQuantityChanged(true); // Set the state to indicate quantity change

        updateQuantity(cardId, newQuantity); // Update quantity directly in the state

        const updatedPrice = cardData.reduce((total, item) => total + item.price * item.quantity, 0);
        setTotalCartPrice(updatedPrice);
      } catch (error) {
        console.error('Error updating quantity:', error);
        setError('Error updating quantity. Please try again later.');
      } finally {
        setLoading(false);
      }
    } else {
      alert('Quantity cannot be less than 1');
    }
  };

  const updateQuantity = (cardId, newQuantity) => {
    const updatedItems = cardData.map((item) => {
      if (item._id === cardId) {
        return { ...item, quantity: newQuantity };
      }
      return item;
    });
    setCardData(updatedItems);
  };


  const removeCartItem = async (cardid) => {
    try {
      // Make an API call to delete the card item with the specified ID
      await axios.delete(`http://localhost:5000/api/card/up/${cardid}`);
      console.log('Item removed from cart:', cardid);
  
      // Update the cart data locally after successful deletion
      const updatedItems = cardData.filter((item) => item.id !== cardid);
      setCardData(updatedItems);
  
      // Update total cart price after removing the item
      const updatedPrice = updatedItems.reduce((total, item) => total + item.price * item.quantity, 0);
      setTotalCartPrice(updatedPrice);
    } catch (error) {
      console.error('Error removing item from cart:', error);
    }
  };
  


  return (
    < div className='cartsection'>
    <h1>Cart Page</h1>
    <table className="cart-table">
      <thead>
        <tr>
          <th>Image</th>
          <th>Name</th>
          <th>Description</th>
          <th>Price</th>
          <th>Quantity</th>
          <th>Total Amount</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
     
        {/* Display fetched card data */}
        {cardData.map((item) => (
          <tr key={item._id}>
            <td><img src={item.img} alt={item.name} /></td>
            <td>{item.productname}</td>
            <td>{item.productdec}</td>
            <td>₹{item.price}</td>
            <td>
    <button className='add-remove' onClick={() => handleQuantityChange(item._id, item.quantity - 1)}>-</button>
    {item.quantity}
    <button className='add-remove2' onClick={() => handleQuantityChange(item._id,item.quantity + 1)}>+</button>
  </td>  
            <td>₹{item.price * item.quantity}</td>
            <td><button className='remove' onClick={() => removeCartItem(item._id)}>Remove</button></td>
          </tr>
        ))}
      </tbody>
    </table>
    <div className="cart-total">
      <h2>Total Price: ₹{totalCartPrice}</h2>
      <button className='checkout' onClick={() => setShowModal(true)}>Checkout</button>
    </div>
    {/* Rest of your modal code */}

   
      {showModal && (
       <div className="modal">
       <div className="modal-content">
         <span className="close" onClick={() => setShowModal(false)}>&times;</span>
         {/* <h2>Order Confirmation</h2>   */}
         <h2>Order Confirmation</h2>
        
         {/* Card-style form */}
    <div className="form-card">
      <div className="form-group">
        <label htmlFor="Name">Name:</label>
        <input type="text" id="Name" name="Name" value={formData.Name} onChange={handleChange} required placeholder="Enter your Name" />
      </div>
      <div className="form-group">
        <label htmlFor="address">Address:</label>
        <input type="text" id="address" value={formData.address} onChange={handleChange} name="address" placeholder="Enter your address" required />
      </div>
      <div className="form-group">
        <label htmlFor="zip">zip:</label>
        <input type="number" id="address" value={formData.zip} onChange={handleChange} name="zip" placeholder="Enter your pin" required />
      </div>
      <div className="form-group">
        <label htmlFor="landmark">Landmark:</label>
        <input type="text" id="landmark" name="landmark" value={formData.landmark} onChange={handleChange} placeholder="Enter landmark (optional)" />
      </div>
      <div className="form-group">
        <label htmlFor="phone">Phone No:</label>
        <input type="number" id="phone" name="phone" value={formData.phone} maxLength={10} onChange={handleChange} placeholder="Enter your phone number" required />
      </div>
      <div className="form-group">
        <label htmlFor="altMobile">Alternate Mobile No:</label>
        <input type="number" id="altMobile" name="altMobile" maxLength={10} value={formData.altMobile} onChange={handleChange} placeholder="Enter alternate mobile number" />
      </div>
    </div>
    <div className="item-cards">
      {cartItems.map((cartItem) => (
        <div className="item-card" key={cartItem.id}>
          <img src={cartItem.img} alt={cartItem.name} />
          <div className="item-details">
            <p>ID: {cartItem.id}</p>
            <p>{cartItem.name}</p>
            <p>{cartItem.description}</p>
            <p>Quantity: {cartItem.quantity}</p>
            <p>Price: ₹{(cartItem.quantity * cartItem.price).toFixed(2)}</p>
          </div>
        </div>
      ))}
    </div>
    <h2>Total Price: ₹{totalCartPrice.toFixed(2)}</h2>
    <button type="submit"onClick={() => { handleProceedToPayment(); }} className='checkout'>Proceed to Payment</button>
       </div>
     </div>
     
      )}
      {showModal2 && (
  <div className="modal">
    <div className="modal-content">
      <span className="close" onClick={() => setShowModal2(false)}>&times;</span>
      <h2>Order Confirmation</h2>
      <form>
      

        <div className="buttons">
          
          <button type="button" className="razorpay" >procced to payment</button>
        </div>
      </form>
    </div>
  </div>
)}
{showModal3 && (
        <div className="modal">
          <div className="modal-content">
            <span className="close" onClick={() => { setShowModal3(false); setShowModal2(true); }}>&times;</span>
            <h2>Order Confirmation</h2>
          
            <p>Total: ₹{totalCartPrice.toFixed(2)}</p>
            <button onClick={setShowModal4(true) } className='checkout'>checkout now</button>
          
          </div>
        </div>
      )}

      {showModal4 && (
        <div className="modal-preview">
          <div className="modal-content-preview">
            <span className="close-preview" onClick={() => { setShowModal4(false); setShowModal(true); }}>&times;</span>
            <h2>Preview Order</h2>
            <ul>
             
              {/* Display form data */}
              <li className='preview-name'> {formData.Name}</li>
              {cartItems.map((cartItem) => (
                <li key={cartItem.id}>
                  {cartItem.quantity}x {cartItem.name} - ₹{(cartItem.quantity * cartItem.price).toFixed(2)}
                </li>
              ))}
              <li>Address: {formData.address}</li>
              <li>Landmark: {formData.landmark}</li>
              <li>Phone No: {formData.phone}</li>
              <li>Alternate Mobile No: {formData.altMobile}</li>
              <li>zip :{formData.zip}</li>
              {/* Display product details */}
              {cartItems.map((cartItem) => (
                <li key={cartItem.id}>
                  {cartItem.description} {cartItem.name} - ₹{(cartItem.price * cartItem.quantity).toFixed(2)}
                </li>
              ))}
            </ul>
          
            <p>Total: ₹{totalCartPrice.toFixed(2)}</p>
            <button onClick={displayRazor} className='checkout'>pay before delivery</button>
           <button >COD</button>
          </div>
        </div>
      )}  

     
    </div>
  );
};

export default CartPage;
