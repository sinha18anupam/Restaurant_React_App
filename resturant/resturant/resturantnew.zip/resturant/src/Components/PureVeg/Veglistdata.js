const Veglistdata =[
    {
      "id": 1,
      "name": "Product 1",
      "img": "https://example.com/product1.jpg",
      "description": "Description for Product 1",
      "price": "120",
      "old_price": "140"
    },
    {
      "id": 2,
      "name": "Product 2",
      "img": "https://example.com/product2.jpg",
      "description": "Description for Product 2",
      "price": "125.00",
      "old_price": "140.00"
    },
    {
      "id": 3,
      "name": "Product 3",
      "img": "https://example.com/product3.jpg",
      "description": "Description for Product 3",
      "price": "130.00",
      "old_price": "140.00"
    },
    {
      "id": 4,
      "name": "Product 4",
      "img": "https://example.com/product4.jpg",
      "description": "Description for Product 4",
      "price": "135.00",
      "old_price": "140.00"
    },
    {
      "id": 5,
      "name": "Product 5",
      "img": "https://example.com/product5.jpg",
      "description": "Description for Product 5",
      "price": "140.00",
      "old_price": "140.00"
    },
    {
      "id": 6,
      "name": "Product 6",
      "img": "https://example.com/product6.jpg",
      "description": "Description for Product 6",
      "price": "145.00",
      "old_price": "140.00"
    },
    {
      "id": 7,
      "name": "Product 7",
      "img": "https://example.com/product7.jpg",
      "description": "Description for Product 7",
      "price": "150.00",
      "old_price": "140.00"
    },
    {
      "id": 8,
      "name": "Product 8",
      "img": "https://example.com/product8.jpg",
      "description": "Description for Product 8",
      "price": "155.00",
      "old_price": "140.00"
    },
    {
      "id": 9,
      "name": "Product 9",
      "img": "https://example.com/product9.jpg",
      "description": "Description for Product 9",
      "price": "160.00",
      "old_price": "140.00"
    },
    {
      "id": 10,
      "name": "Product 10",
      "img": "https://example.com/product10.jpg",
      "description": "Description for Product 10",
      "price": "165.00",
      "old_price": "140.00"
    },
    {
      "id": 11,
      "name": "Product 11",
      "img": "https://example.com/product11.jpg",
      "description": "Description for Product 11",
      "price": "170.00",
      "old_price": "140.00"
    },
    {
      "id": 12,
      "name": "Product 12",
      "img": "https://example.com/product12.jpg",
      "description": "Description for Product 12",
      "price": "175.00",
      "old_price": "140.00"
    },
    {
      "id": 13,
      "name": "Product 13",
      "img": "https://example.com/product13.jpg",
      "description": "Description for Product 13",
      "price": "180.00",
      "old_price": "140.00"
    },
    {
      "id": 14,
      "name": "Product 14",
      "img": "https://example.com/product14.jpg",
      "description": "Description for Product 14",
      "price": "185.00",
      "old_price": "140.00"
    },
    {
      "id": 15,
      "name": "Product 15",
      "img": "https://example.com/product15.jpg",
      "description": "Description for Product 15",
      "price": "190.00",
      "old_price": "140.00"
    },
    {
      "id": 16,
      "name": "Product 16",
      "img": "https://example.com/product16.jpg",
      "description": "Description for Product 16",
      "price": "195.00",
      "old_price": "140.00"
    },
    {
      "id": 17,
      "name": "Product 17",
      "img": "https://example.com/product17.jpg",
      "description": "Description for Product 17",
      "price": "200.00",
      "old_price": "140.00"
    },
    {
      "id": 18,
      "name": "Product 18",
      "img": "https://example.com/product18.jpg",
      "description": "Description for Product 18",
      "price": "205.00",
      "old_price": "140.00"
    },
    {
      "id": 19,
      "name": "Product 19",
      "img": "https://example.com/product19.jpg",
      "description": "Description for Product 19",
      "price": "210.00",
      "old_price": "140.00"
    },
    {
      "id": 20,
      "name": "Product 20",
      "img": "https://example.com/product20.jpg",
      "description": "Description for Product 20",
      "price": "215.00",
      "old_price": "140.00"
    },
    {
      "id": 21,
      "name": "Product 21",
      "img": "https://example.com/product21.jpg",
      "description": "Description for Product 21",
      "price": "220.00",
      "old_price": "140.00"
    },
    {
      "id": 22,
      "name": "Product 22",
      "img": "https://example.com/product22.jpg",
      "description": "Description for Product 22",
      "price": "225.00",
      "old_price": "140.00"
    },
    {
      "id": 23,
      "name": "Product 23",
      "img": "https://example.com/product23.jpg",
      "description": "Description for Product 23",
      "price": "230.00",
      "old_price": "140.00"
    },
    {
      "id": 24,
      "name": "Product 24",
      "img": "https://example.com/product24.jpg",
      "description": "Description for Product 24",
      "price": "235.00",
      "old_price": "140.00"
    },
    {
      "id": 25,
      "name": "Product 25",
      "img": "https://example.com/product25.jpg",
      "description": "Description for Product 25",
      "price": "240.00",
      "old_price": "140.00"
    },
    {
      "id": 26,
      "name": "Product 26",
      "img": "https://example.com/product26.jpg",
      "description": "Description for Product 26",
      "price": "245.00",
      "old_price": "140.00"
    },
    {
      "id": 27,
      "name": "Product 27",
      "img": "https://example.com/product27.jpg",
      "description": "Description for Product 27",
      "price": "250.00",
      "old_price": "140.00"
    },
    {
      "id": 28,
      "name": "Product 28",
      "img": "https://example.com/product28.jpg",
      "description": "Description for Product 28",
      "price": "255.00",
      "old_price": "140.00"
    },
    {
      "id": 29,
      "name": "Product 29",
      "img": "https://example.com/product29.jpg",
      "description": "Description for Product 29",
      "price": "260.00",
      "old_price": "140.00"
    },
    {
      "id": 30,
      "name": "Product 30",
      "img": "https://example.com/product30.jpg",
      "description": "Description for Product 30",
      "price": "265.00",
      "old_price": "140.00"
    },
    {
      "id": 31,
      "name": "Product 31",
      "img": "https://example.com/product31.jpg",
      "description": "Description for Product 31",
      "price": "270.00",
      "old_price": "140.00"
    },
    {
      "id": 32,
      "name": "Product 32",
      "img": "https://example.com/product32.jpg",
      "description": "Description for Product 32",
      "price": "275.00",
      "old_price": "140.00"
    },
    {
      "id": 33,
      "name": "Product 33",
      "img": "https://example.com/product33.jpg",
      "description": "Description for Product 33",
      "price": "280.00",
      "old_price": "140.00"
    },
    {
      "id": 34,
      "name": "Product 34",
      "img": "https://example.com/product34.jpg",
      "description": "Description for Product 34",
      "price": "285.00",
      "old_price": "140.00"
    },
    {
      "id": 35,
      "name": "Product 35",
      "img": "https://example.com/product35.jpg",
      "description": "Description for Product 35",
      "price": "290.00",
      "old_price": "140.00"
    },
    {
      "id": 36,
      "name": "Product 36",
      "img": "https://example.com/product36.jpg",
      "description": "Description for Product 36",
      "price": "295.00",
      "old_price": "140.00"
    },
    {
      "id": 37,
      "name": "Product 37",
      "img": "https://example.com/product37.jpg",
      "description": "Description for Product 37",
      "price": "300.00",
      "old_price": "140.00"
    },
    {
      "id": 38,
      "name": "Product 38",
      "img": "https://example.com/product38.jpg",
      "description": "Description for Product 38",
      "price": "305.00",
      "old_price": "140.00"
    },
    {
      "id": 39,
      "name": "Product 39",
      "img": "https://example.com/product39.jpg",
      "description": "Description for Product 39",
      "price": "310.00",
      "old_price": "140.00"
    },
    {
      "id": 40,
      "name": "Product 40",
      "img": "https://example.com/product40.jpg",
      "description": "Description for Product 40",
      "price": "315.00",
      "old_price": "140.00"
    },
    {
      "id": 41,
      "name": "Product 41",
      "img": "https://example.com/product41.jpg",
      "description": "Description for Product 41",
      "price": "320.00",
      "old_price": "140.00"
    },
    {
      "id": 42,
      "name": "Product 42",
      "img": "https://example.com/product42.jpg",
      "description": "Description for Product 42",
      "price": "325.00",
      "old_price": "140.00"
    },
    {
      "id": 43,
      "name": "Product 43",
      "img": "https://example.com/product43.jpg",
      "description": "Description for Product 43",
      "price": "330.00",
      "old_price": "140.00"
    },
    {
      "id": 44,
      "name": "Product 44",
      "img": "https://example.com/product44.jpg",
      "description": "Description for Product 44",
      "price": "335.00",
      "old_price": "140.00"
    },
    {
      "id": 45,
      "name": "Product 45",
      "img": "https://example.com/product45.jpg",
      "description": "Description for Product 45",
      "price": "340.00",
      "old_price": "140.00"
    },
    {
      "id": 46,
      "name": "Product 46",
      "img": "https://example.com/product46.jpg",
      "description": "Description for Product 46",
      "price": "345.00",
      "old_price": "140.00"
    },
    {
      "id": 47,
      "name": "Product 47",
      "img": "https://example.com/product47.jpg",
      "description": "Description for Product 47",
      "price": "350.00",
      "old_price": "140.00"
    },
    {
      "id": 48,
      "name": "Product 48",
      "img": "https://example.com/product48.jpg",
      "description": "Description for Product 48",
      "price": "355.00",
      "old_price": "140.00"
    },
    {
      "id": 49,
      "name": "Product 49",
      "img": "https://example.com/product49.jpg",
      "description": "Description for Product 49",
      "price": "360.00",
      "old_price": "140.00"
    },
    {
      "id": 50,
      "name": "Product 50",
      "img": "https://example.com/product50.jpg",
      "description": "Description for Product 50",
      "price": "365.00",
      "old_price": "140.00"
    },
    {
      "id": 51,
      "name": "Product 51",
      "img": "https://example.com/product51.jpg",
      "description": "Description for Product 51",
      "price": "370.00",
      "old_price": "140.00"
    },
    {
      "id": 52,
      "name": "Product 52",
      "img": "https://example.com/product52.jpg",
      "description": "Description for Product 52",
      "price": "375.00",
      "old_price": "140.00"
    },
    {
      "id": 53,
      "name": "Product 53",
      "img": "https://example.com/product53.jpg",
      "description": "Description for Product 53",
      "price": "380.00",
      "old_price": "140.00"
    },
    {
      "id": 54,
      "name": "Product 54",
      "img": "https://example.com/product54.jpg",
      "description": "Description for Product 54",
      "price": "385.00",
      "old_price": "140.00"
    },
    {
      "id": 55,
      "name": "Product 55",
      "img": "https://example.com/product55.jpg",
      "description": "Description for Product 55",
      "price": "390.00",
      "old_price": "140.00"
    },
    {
      "id": 56,
      "name": "Product 56",
      "img": "https://example.com/product56.jpg",
      "description": "Description for Product 56",
      "price": "395.00",
      "old_price": "140.00"
    },
    {
      "id": 57,
      "name": "Product 57",
      "img": "https://example.com/product57.jpg",
      "description": "Description for Product 57",
      "price": "400.00",
      "old_price": "140.00"
    },
    {
      "id": 58,
      "name": "Product 58",
      "img": "https://example.com/product58.jpg",
      "description": "Description for Product 58",
      "price": "405.00",
      "old_price": "140.00"
    },
    {
      "id": 59,
      "name": "Product 59",
      "img": "https://example.com/product59.jpg",
      "description": "Description for Product 59",
      "price": "410.00",
      "old_price": "140.00"
    },
    {
      "id": 60,
      "name": "Product 60",
      "img": "https://example.com/product60.jpg",
      "description": "Description for Product 60",
      "price": "415.00",
      "old_price": "140.00"
    },
    {
      "id": 61,
      "name": "Product 61",
      "img": "https://example.com/product61.jpg",
      "description": "Description for Product 61",
      "price": "420.00",
      "old_price": "140.00"
    },
    {
      "id": 62,
      "name": "Product 62",
      "img": "https://example.com/product62.jpg",
      "description": "Description for Product 62",
      "price": "425.00",
      "old_price": "140.00"
    },
    {
      "id": 63,
      "name": "Product 63",
      "img": "https://example.com/product63.jpg",
      "description": "Description for Product 63",
      "price": "430.00",
      "old_price": "140.00"
    },
    {
      "id": 64,
      "name": "Product 64",
      "img": "https://example.com/product64.jpg",
      "description": "Description for Product 64",
      "price": "435.00",
      "old_price": "140.00"
    },
    {
      "id": 65,
      "name": "Product 65",
      "img": "https://example.com/product65.jpg",
      "description": "Description for Product 65",
      "price": "440.00",
      "old_price": "140.00"
    },
    {
      "id": 66,
      "name": "Product 66",
      "img": "https://example.com/product66.jpg",
      "description": "Description for Product 66",
      "price": "445.00",
      "old_price": "140.00"
    },
    {
      "id": 67,
      "name": "Product 67",
      "img": "https://example.com/product67.jpg",
      "description": "Description for Product 67",
      "price": "450.00",
      "old_price": "140.00"
    },
    {
      "id": 68,
      "name": "Product 68",
      "img": "https://example.com/product68.jpg",
      "description": "Description for Product 68",
      "price": "455.00",
      "old_price": "140.00"
    },
    {
      "id": 69,
      "name": "Product 69",
      "img": "https://example.com/product69.jpg",
      "description": "Description for Product 69",
      "price": "460.00",
      "old_price": "140.00"
    },
    {
      "id": 70,
      "name": "Product 70",
      "img": "https://example.com/product70.jpg",
      "description": "Description for Product 70",
      "price": "465.00",
      "old_price": "140.00"
    },
    {
      "id": 71,
      "name": "Product 71",
      "img": "https://example.com/product71.jpg",
      "description": "Description for Product 71",
      "price": "470.00",
      "old_price": "140.00"
    },
    {
      "id": 72,
      "name": "Product 72",
      "img": "https://example.com/product72.jpg",
      "description": "Description for Product 72",
      "price": "475.00",
      "old_price": "140.00"
    },
    {
      "id": 73,
      "name": "Product 73",
      "img": "https://example.com/product73.jpg",
      "description": "Description for Product 73",
      "price": "480.00",
      "old_price": "140.00"
    },
    {
      "id": 74,
      "name": "Product 74",
      "img": "https://example.com/product74.jpg",
      "description": "Description for Product 74",
      "price": "485.00",
      "old_price": "140.00"
    },
    {
      "id": 75,
      "name": "Product 75",
      "img": "https://example.com/product75.jpg",
      "description": "Description for Product 75",
      "price": "490.00",
      "old_price": "140.00"
    },
    {
      "id": 76,
      "name": "Product 76",
      "img": "https://example.com/product76.jpg",
      "description": "Description for Product 76",
      "price": "495.00",
      "old_price": "140.00"
    },
    {
      "id": 77,
      "name": "Product 77",
      "img": "https://example.com/product77.jpg",
      "description": "Description for Product 77",
      "price": "500.00",
      "old_price": "140.00"
    },
    {
      "id": 78,
      "name": "Product 78",
      "img": "https://example.com/product78.jpg",
      "description": "Description for Product 78",
      "price": "505.00",
      "old_price": "140.00"
    },
    {
      "id": 79,
      "name": "Product 79",
      "img": "https://example.com/product79.jpg",
      "description": "Description for Product 79",
      "price": "510.00",
      "old_price": "140.00"
    },
    {
      "id": 80,
      "name": "Product 80",
      "img": "https://example.com/product80.jpg",
      "description": "Description for Product 80",
      "price": "515.00",
      "old_price": "140.00"
    }
  ]
  

export default Veglistdata;