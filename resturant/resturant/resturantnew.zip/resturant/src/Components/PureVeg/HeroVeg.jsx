import React from "react";
import "./HeroVeg.css";

const HeroVeg = () => {
  return (
    <div>
      <div class="at-container">
        <div class="at-item">
          <section id="home">
            <h1 class="h-primary">Welcome to MyOnlineMeal</h1>
            <p>
              Lorem ipsum dolor sit amet consectetur adipisicing elit. Beatae
              earum assumenda dolores.
            </p>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. </p>
            <button class="btn">Order Now</button>
          
          </section>
        </div>
      </div>

     
    </div>
  );
};

export default HeroVeg;
