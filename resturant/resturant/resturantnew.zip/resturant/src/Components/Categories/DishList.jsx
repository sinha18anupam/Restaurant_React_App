// import React from 'react';
// import { useNavigate } from 'react-router-dom';
// import frontPagedata from '../../Components/Categories/frontPagedata';

// const DishList = () => {
//   const navigate = useNavigate();

//   const handleAddToCart = (item) => {
//     navigate('/cart', { state: { item: item } });
//   };

//   return (
//     <div className='new-collection'>
//       <hr/>
//       <div className="collection">
//         {frontPagedata.map((item, i) => ( 
//           <div key={i} className="product-item">
//             <img src={item.img} alt={item.name} />
//             <h3>{item.name}</h3>
//             <p>{item.description}</p>
//             <h3><b>₹{item.price.toFixed(2)}</b></h3> {/* Fix toFixed */}
//             {item.oldPrice && <del>₹{item.oldPrice.toFixed(2)}</del>} {/* Check if oldPrice exists */}
//             <br/>
//             <button className='add-to-cart' onClick={() => handleAddToCart(item)}>Add to Cart</button>
//           </div>
//         ))}
//       </div>
//     </div>
//   );
// };

// export default DishList;

// import React from 'react';
// import { useNavigate } from 'react-router-dom';
// import frontPagedata from '../../Components/Categories/frontPagedata';

// const DishList = () => {
//   const navigate = useNavigate();

//   const handleAddToCart = (item) => {
//     navigate('/cart', { state: { item: item } });
//   };

//   return (
//     <div className='new-collection'>
//       <hr/>
//       <div className="collection">
//         {frontPagedata.map((item, i) => ( 
//           <div key={i} className="product-item">
//             <img src={item.img} alt={item.name} />
//             <h3>{item.name}</h3>
//             <p>{item.description}</p>
//             <h3><b>₹{item.price.toFixed(2)}</b></h3> {/* Fix toFixed */}
//             {item.oldPrice && <del>₹{item.oldPrice.toFixed(2)}</del>} {/* Check if oldPrice exists */}
//             <br/>
//             <button className='add-to-cart' onClick={() => handleAddToCart(item)}>Add to Cart</button>
//           </div>
//         ))}
//       </div>
//     </div>
//   );
// };

// export default DishList;
import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import frontPagedata from '../../Components/Categories/frontPagedata';
import { useCart } from '../CartPage/CartContext'; // Import useCart hook
import axios from 'axios';

const DishList = () => {
  const navigate = useNavigate();
  const [searchInput, setSearchInput] = useState('');
  const [filteredProducts, setFilteredProducts] = useState([]);
  const { addToCart } = useCart(); // Use addToCart function from CartContext
  const { updateCartCount } = useCart(); // Use updateCartCount function from useCart hook
 
  const handleAddToCart = async (item) => {
    const userData = localStorage.getItem('userid');
    if (!userData) {
        navigate('/signup'); // Corrected typo here
        return;
    }

    const valu = {
        product: item.productid,
        iduser: userData,
        quantity: 1
    };

    console.log('Value to be posted:', valu);

    try {
        const response = await axios.post('http://localhost:5000/api/card/post', valu);
        console.log('Response:', response.data);
    } catch (error) {
        console.error('Error posting to card:', error);
    }
};


   const [products, setProducts] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get('http://localhost:5000/api/product/get');
        setProducts(response.data.products);
        setFilteredProducts(response.data.products); // Initialize filteredProducts with all products
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();
  }, []);
  const handleSearchInputChange = (e) => {
    setSearchInput(e.target.value);
    filterProducts(e.target.value);
  };
  const filterProducts = (searchTerm) => {
    if (searchTerm.trim() === '') {
      setFilteredProducts(products); // If search input is empty, show all products
    } else {
      const filtered = products.filter((product) =>
        product.productname.toLowerCase().includes(searchTerm.toLowerCase())
      );
      setFilteredProducts(filtered);
    }
  };


   // Add item to cart
  return (
    <div className='new-collection'>
    <hr/>
    <div className="search-container">
        <input
          type="text"
          placeholder="Search by product name"
          value={searchInput}
          onChange={handleSearchInputChange}
          style={{
            width: '50%',
            padding: '10px',
            border: '1px solid #ccc',
            borderRadius: '5px',
            boxSizing: 'border-box',
            fontSize: '16px',
            // Add additional styles as needed
          }}
        />
      </div>
    
    <div className="collection">
    {filteredProducts.map((item, i) => ( 
          <div key={i} className="product-item">
            <img src={item.img} alt={item.productname}   style={{width:'250px',
    height:'250px'}}/>
            <h3>{item.productname}</h3>
            <p>{item.productdec}</p>
            <h3><b>₹{item.price}</b></h3>
            {item.oldprice && <del>₹{item.oldprice.toFixed(2)}</del>}
            <br/>
            <Link to="/cart">
              <button className='' onClick={() => handleAddToCart(item)}>Add to Cart</button>
            </Link>
          </div>
        ))}
    </div>
  </div>
  );
};

export default DishList;
