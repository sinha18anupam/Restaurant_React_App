import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './Register.css'
import axios from 'axios';

const Register = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    username: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };
  const handleSubmit = async (e) => { // Make handleSubmit async
    e.preventDefault();
    try {
      // Send POST request to register user
      const response = await axios.post('http://localhost:5000/api/auth/register', formData);
      console.log('Registration successful:', response.data);
      navigate('/login');
    } catch (error) {
      console.error('Error registering user:', error);
      // Handle error (e.g., display error message)
    }
  };

  const handleLoginClick = () => {
    // Navigate to the login page
    navigate('/login');
  };
  return (
    <>
     <div className='main-page-register'>
        <div className="register-page">
          <h2>Registration</h2>
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label htmlFor="email">Email:</label>
              <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                required
              />
            </div>
            <div className="form-group">
              <label htmlFor="username">Username:</label>
              <input
                type="text"
                id="username"
                name="username"
                value={formData.username}
                onChange={handleChange}
                required
              />
            </div>
            <div className="form-group">
              <label htmlFor="password">Password:</label>
              <input
                type="password"
                id="password"
                name="password"
                value={formData.password}
                onChange={handleChange}
                required
              />
            </div>
          
            <button type="submit">Register</button>
            <button  className='gotologin' onClick={handleLoginClick}>Already signed up? Move to login</button>
          </form>
        </div>
      </div>
    </>
  );
};

export default Register;
