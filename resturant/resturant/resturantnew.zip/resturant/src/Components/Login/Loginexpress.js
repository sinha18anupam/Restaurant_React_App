const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql');

const app = express();

// Body parser middleware
app.use(bodyParser.urlencoded({ extended: true }));

// MySQL connection
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'your_mysql_username',
    password: 'your_mysql_password',
    database: 'registrationDB'
});

connection.connect((err) => {
    if (err) {
        console.error('Error connecting to MySQL database: ' + err.stack);
        return;
    }
    console.log('Connected to MySQL database.');
});

// Registration route
app.get('/register', (req, res) => {
    res.sendFile(__dirname + '/registrationForm.html');
});

app.post('/register', (req, res) => {
    const { email, password, confirmPassword } = req.body;
    
    // Check if password and confirm password match
    if (password !== confirmPassword) {
        return res.status(400).send('Passwords do not match.');
    }
    
    // Insert user into database
    const sql = 'INSERT INTO users (email, password) VALUES (?, ?)';
    connection.query(sql, [email, password], (err, result) => {
        if (err) {
            console.error('Error registering user: ' + err.stack);
            return res.status(500).send('Internal Server Error.');
        }
        console.log('User registered successfully.');
        res.status(201).send('User registered successfully.');
    });
});

// Login route
app.get('/login', (req, res) => {
    res.sendFile(__dirname + '/loginForm.html');
});

app.post('/login', (req, res) => {
    const { email, password } = req.body;
    
    // Find user by email and password
    const sql = 'SELECT * FROM users WHERE email = ? AND password = ?';
    connection.query(sql, [email, password], (err, result) => {
        if (err) {
            console.error('Error logging in: ' + err.stack);
            return res.status(500).send('Internal Server Error.');
        }
        if (result.length === 0) {
            return res.status(401).send('Invalid email or password.');
        }
        console.log('Login successful.');
        res.status(200).send('Login successful.');
    });
});

// Server listening
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(Server running on port ${PORT}));