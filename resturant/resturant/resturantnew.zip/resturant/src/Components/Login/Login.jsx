import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './Login.css'
import axios from 'axios';
const Login = () => {
    const navigate = useNavigate();
  const [formData, setFormData] = useState({
    email: '',
    password: '',
  });
  const [errors, setErrors] = useState({});
  const [successMessage, setSuccessMessage] = useState('');

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const validateForm = () => {
    let errors = {};

    if (!formData.email.trim()) {
      errors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      errors.email = 'Email is invalid';
    }
    if (!formData.password.trim()) {
      errors.password = 'Password is required';
    }

    setErrors(errors);
    return Object.keys(errors).length === 0; // Return true if no errors
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:5000/api/auth/login', formData);
      console.log('Login successful:', response.data);
      
      // Save user ID to local storage
      localStorage.setItem('userid', response.data.userid);
      
      setSuccessMessage('Login successful');
      navigate('/');
    } catch (error) {
      if (error.response && error.response.data) {
        setErrors("email/password does not match");
      } else {
        console.error('Error logging in:', error.message);
      }
    }
  };  return (
    <>
    <div className='main-page-login'>
      <div className="login-page">
        <h2>Login</h2>
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="email">Email</label>
            <input
              type="email"
              id="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
            />
            {errors.email && <span className="error">{errors.email}</span>}
          </div>
          <div className="form-group">
            <label htmlFor="password">Password</label>
            <input
              type="password"
              id="password"
              name="password"
              value={formData.password}
              onChange={handleChange}
            />
            {errors.password && <span className="error">{errors.password}</span>}
          </div>
          <button type="submit" >Login</button>
          {Object.keys(errors).length > 0 && <p>{errors.email || errors.password}</p>}

          {successMessage && <div className="success">{successMessage}</div>}
        </form>

      </div>
    </div>
    </>
  );
};

export default Login;
