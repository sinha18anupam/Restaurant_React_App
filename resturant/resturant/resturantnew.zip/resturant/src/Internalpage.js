import React from 'react'
import Navbar from './Components/Navbar/Navbar';
import Hero from './Components/Categories/Hero';
import { Route, Router, Routes } from 'react-router-dom';
import MainCategories from './Components/Categories/MainCategories';
import MainService from './Components/Services/MainService';
import Pureveg from './Components/PureVeg/Pureveg';
import CartPage from './Components/CartPage/CartPage';
import Footer from './Components/Footer/Footer';
import { CartProvider } from './Components/CartPage/CartContext';
import Subcategories from './Components/PureVeg/Pureveg';


const InternalPage = () => (
    <>
   <div>
      
      <Routes>
      
      </Routes>
    
    
      </div>
    </>
  );      

export default InternalPage